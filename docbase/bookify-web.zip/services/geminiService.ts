
import { GoogleGenAI, Type } from "@google/genai";
import { BookPage } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const processWebContent = async (html: string, url: string): Promise<{ title: string; author: string; pages: BookPage[] }> => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `
      Act as a world-class book editor specializing in converting complex web structures, specifically lore wikis and project indexes, into elegant digital books.
      
      I will provide you with the HTML of a webpage (likely a lore index or wiki landing page).
      
      Your specific goals:
      1. Detect and identify the main Title and the project Source/Author.
      2. PRESERVE HIERARCHY: If you see a nested tree structure (lists within lists), format the first 1-2 pages as a "Table of Contents" or "Universe Overview" that maps this structure exactly using indentation and bullets.
      3. FUNCTIONAL LINKS: Preserve core navigation links. If a link points elsewhere in the wiki, format it clearly so it stands out.
      4. SEGMENTATION: Do not truncate content. If the text is dense, create as many logical pages as needed. 
      5. TONE: Maintain a literary, scholarly tone in headers.
      
      URL of source: ${url}
      HTML Content:
      ${html.substring(0, 40000)}
    `,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          author: { type: Type.STRING },
          pages: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                content: { type: Type.STRING },
                pageNumber: { type: Type.INTEGER }
              },
              required: ["title", "content", "pageNumber"]
            }
          }
        },
        required: ["title", "author", "pages"]
      }
    }
  });

  const data = JSON.parse(response.text);
  return data;
};
