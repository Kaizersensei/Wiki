
export const fetchUrlContent = async (url: string): Promise<string> => {
  const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
  const response = await fetch(proxyUrl);
  if (!response.ok) throw new Error("Failed to fetch content via proxy");
  const data = await response.json();
  return data.contents;
};
